## TODO
 * Continue updating Documentation
    * Progress so far: Completed Game.js
 * Find a way to auto-generate constants